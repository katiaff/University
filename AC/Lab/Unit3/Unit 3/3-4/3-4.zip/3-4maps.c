#include <stdio.h>

int main(void) {
  printf("Press [ENTER] to continue");
  getchar(); /* Wait for ENTER */

  return 0;
}
